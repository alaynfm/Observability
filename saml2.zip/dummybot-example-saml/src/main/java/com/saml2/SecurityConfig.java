package com.saml2;

import java.io.InputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.saml2.core.Saml2X509Credential;
import org.springframework.security.saml2.core.Saml2X509Credential.Saml2X509CredentialType;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistration;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.util.Assert;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
import org.springframework.security.saml2.provider.service.registration.InMemoryRelyingPartyRegistrationRepository;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrations;


@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter { 

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests(authorize -> authorize
            	.antMatchers("/css/**", "/js/**", "/img/**").permitAll()
                .antMatchers("/").permitAll()  // Permitir acceso no autenticado a la página de inicio
                .anyRequest().authenticated()  // Requerir autenticación para cualquier otra solicitud
            )
            .saml2Login(saml2Login -> saml2Login
                .loginPage("/")  // Usar la página de inicio como página de login
                .defaultSuccessUrl("/loginSuccess", true)  // Redirigir aquí después de un login exitoso
            )
            .logout(logout -> logout
                .logoutSuccessHandler(logoutSuccessHandler())  // Manejar el logout personalizado
            );
    }

    private LogoutSuccessHandler logoutSuccessHandler() {
        return (request, response, authentication) -> {
            // Redirigir a la página de inicio después del logout
            response.sendRedirect("/");
        };
    }
    
/*   
    --------------------
    SAML 2.0 load .xml
    --------------------
 

    
    @Bean
    public RelyingPartyRegistrationRepository relyingPartyRegistrationRepository() {
        String metadataLocation = "classpath:/metadata/idp-metadata.xml";
        RelyingPartyRegistration registration = RelyingPartyRegistrations
            .fromMetadataLocation(metadataLocation)
            .registrationId("miIdp")
            .build();
        return new InMemoryRelyingPartyRegistrationRepository(registration);
    }
    
    
*/   

/*
    
    ----------------------------
    SAML 2.0 create own idp .xml
    ----------------------------
*/   
    @Value("${saml2.relyingparty.registration.miIdp.registration-id}")
    private String registrationId;
    @Value("${saml2.relyingparty.registration.miIdp.identityprovider.entity-id}")
    private String entityId;
    @Value("${saml2.relyingparty.registration.miIdp.identityprovider.sso-url}")
    private String ssoUrl;
    @Value("classpath:${saml2.relyingparty.registration.miIdp.identityprovider.certificate-location}")
    private Resource certificateResource;
    
    @Bean
    protected RelyingPartyRegistrationRepository relyingPartyRegistrations() throws Exception {
        Assert.notNull(certificateResource, "Certificate resource must not be null");
        X509Certificate certificate;
        try {
            certificate = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(certificateResource.getInputStream());
        } catch (Exception e) {
            throw new IllegalArgumentException("Error loading verification certificate", e);
        }

        Saml2X509Credential credential = new Saml2X509Credential(certificate, Saml2X509Credential.Saml2X509CredentialType.VERIFICATION);

        RelyingPartyRegistration registration = RelyingPartyRegistration
                .withRegistrationId(registrationId)
                .assertingPartyDetails(party -> party
                    .entityId(entityId)
                    .singleSignOnServiceLocation(ssoUrl)
                    .wantAuthnRequestsSigned(false)
                    .verificationX509Credentials(c -> c.add(credential))
                ).build();

        return new InMemoryRelyingPartyRegistrationRepository(registration);
    }
}
