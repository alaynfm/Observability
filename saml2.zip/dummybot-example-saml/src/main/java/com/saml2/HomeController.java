package com.saml2;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.security.Principal;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/loginSuccess")
    public String loginSuccess(Principal principal, Model model) { // Añade Model como parámetro
        // Asume que el objeto Principal no es nulo
        String username = principal.getName(); // Obtiene el nombre de usuario del objeto Principal
        model.addAttribute("username", username);
        model.addAttribute("title", "test");
        return "loginSuccess"; // Nombre de la vista (archivo HTML en src/main/resources/templates)
    }
}
