package com.saml2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamlApplication {

    public static void main(String[] args) {
        SpringApplication.run(SamlApplication.class, args);
    }
}
